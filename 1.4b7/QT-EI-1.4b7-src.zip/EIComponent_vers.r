
#include "mactypes.r"
#include "systypes.r"

#include "EI_IDs.h"

resource 'vers' (1){
	kEI_VersionNum, 
	verUS, 
	kEI_VersionShort,
	kEI_VersionShort ", Copyright 1998-2004 Apple Computer, Inc."
};
